/*
  CS210 Project Three - Corner Grocer (Single-file, Rubric Compliant)
  - Data encapsulation: GroceryItem (private fields + getters + increment())
  - Inventory manages std::map<std::string,GroceryItem> (no console I/O)
  - Menu 1..4 with validation; no while(true)
  - frequency.dat written at startup
  - C++14 compatible
*/

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

/*---------------------- GroceryItem ----------------------*/
class GroceryItem {
public:
    explicit GroceryItem(const std::string& normalizedName = std::string(),
        int initialCount = 0)
        : name_(normalizedName), count_(initialCount) {
    }

    const std::string& getName() const { return name_; }
    int  getCount() const { return count_; }
    void increment() { ++count_; }

private:
    std::string name_;
    int count_;
};

/*---------------------- Inventory ------------------------*/
class Inventory {
public:
    // Read tokens from file, normalize, and count. Throws on failure.
    void loadFromFile(const std::string& inputPath) {
        std::ifstream in(inputPath.c_str());
        if (!in) {
            throw std::runtime_error(
                "Unable to open input file: " + inputPath +
                "\nTip: Set Debugging?Working Directory to $(ProjectDir) "
                "or place the file beside the .exe.");
        }
        std::string token;
        while (in >> token) {
            const std::string key = normalize(token);
            if (!key.empty()) ensureItem(key).increment();
        }
    }

    // Frequency for one raw name (normalized internally). 0 if missing.
    int lookup(const std::string& raw) const {
        const std::string key = normalize(raw);
        if (key.empty()) return 0;
        std::map<std::string, GroceryItem>::const_iterator it = items_.find(key);
        return (it == items_.end()) ? 0 : it->second.getCount();
    }

    // Snapshot of all <name,count> pairs, sorted alphabetically.
    std::vector<std::pair<std::string, int> > allFrequencies() const {
        std::vector<std::pair<std::string, int> > out;
        out.reserve(items_.size());
        for (std::map<std::string, GroceryItem>::const_iterator it = items_.begin();
            it != items_.end(); ++it) {
            out.push_back(std::make_pair(it->first, it->second.getCount()));
        }
        return out;
    }

    // "<item> <****>" lines (asterisks == count).
    std::vector<std::string> histogramLines(char mark = '*') const {
        std::vector<std::string> lines;
        const std::vector<std::pair<std::string, int> > freqs = allFrequencies();
        for (std::size_t i = 0; i < freqs.size(); ++i) {
            const std::string& name = freqs[i].first;
            const int count = freqs[i].second;
            lines.push_back(name + " " + std::string(static_cast<std::size_t>(count), mark));
        }
        return lines;
    }

    // Write "<item> <count>" to backup file. Throws on failure.
    void writeBackupFile(const std::string& outPath) const {
        std::ofstream out(outPath.c_str());
        if (!out) throw std::runtime_error("Unable to open backup file: " + outPath);
        for (std::map<std::string, GroceryItem>::const_iterator it = items_.begin();
            it != items_.end(); ++it) {
            out << it->first << ' ' << it->second.getCount() << '\n';
        }
    }

private:
    std::map<std::string, GroceryItem> items_;

    GroceryItem& ensureItem(const std::string& normalizedName) {
        std::map<std::string, GroceryItem>::iterator it = items_.find(normalizedName);
        if (it == items_.end())
            it = items_.insert(std::make_pair(normalizedName, GroceryItem(normalizedName, 0))).first;
        return it->second;
    }

    // Lowercase; trim leading/trailing punctuation; keep '-' or '\'' only when between alnum.
    static std::string normalize(const std::string& s) {
        if (s.empty()) return std::string();

        std::string out = s;
        for (std::size_t i = 0; i < out.size(); ++i) {
            unsigned char c = static_cast<unsigned char>(out[i]);
            out[i] = static_cast<char>(std::tolower(c));
        }

        std::size_t start = 0;
        while (start < out.size() && std::ispunct(static_cast<unsigned char>(out[start]))) ++start;
        if (start >= out.size()) return std::string();

        std::size_t end = out.size();
        while (end > start && std::ispunct(static_cast<unsigned char>(out[end - 1]))) --end;

        out = out.substr(start, end - start);
        if (out.empty()) return std::string();

        std::string keep;
        keep.reserve(out.size());
        for (std::size_t i = 0; i < out.size(); ++i) {
            char c = out[i];
            if (std::isalnum(static_cast<unsigned char>(c))) {
                keep.push_back(c);
            }
            else if ((c == '-' || c == '\'') &&
                i > 0 && i + 1 < out.size() &&
                std::isalnum(static_cast<unsigned char>(out[i - 1])) &&
                std::isalnum(static_cast<unsigned char>(out[i + 1]))) {
                keep.push_back(c);
            }
        }
        return keep;
    }
};

/*---------------- Presentation (UI only) ------------------*/
static void printFrequencies(const std::vector<std::pair<std::string, int> >& freqs) {
    if (freqs.empty()) { std::cout << "(No items found.)\n"; return; }
    std::size_t maxLen = 0;
    for (std::size_t i = 0; i < freqs.size(); ++i)
        if (freqs[i].first.size() > maxLen) maxLen = freqs[i].first.size();

    std::cout << "\n=== All Item Frequencies ===\n";
    for (std::size_t i = 0; i < freqs.size(); ++i) {
        std::cout << std::left
            << std::setw(static_cast<int>(maxLen) + 1)  // cast silences analyzer info
            << freqs[i].first
            << " " << freqs[i].second << "\n";
    }
}

static void printHistogram(const std::vector<std::string>& lines) {
    if (lines.empty()) { std::cout << "(No items found.)\n"; return; }
    std::cout << "\n=== Item Purchase Histogram ===\n";
    for (std::size_t i = 0; i < lines.size(); ++i) std::cout << lines[i] << "\n";
}

/*------------------------------ main ------------------------------*/
int main() {
    const std::string INPUT_FILE = "CS210_Project_Three_Input_File.txt";
    const std::string BACKUP_FILE = "frequency.dat";

    try {
        Inventory inv;
        inv.loadFromFile(INPUT_FILE);      // loads & counts
        inv.writeBackupFile(BACKUP_FILE);  // Data File Creation ?

        int choice = 0;
        do {
            std::cout << "\n------ Corner Grocer Menu ------\n"
                "1. Look up item frequency\n"
                "2. Print all item frequencies\n"
                "3. Print histogram\n"
                "4. Exit\n"
                "Choose an option (1-4): ";

            if (!(std::cin >> choice)) {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                choice = 0;
            }
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            if (choice == 1) {
                std::cout << "Enter an item to look up: ";
                std::string query;
                std::getline(std::cin, query);
                if (query.empty()) {
                    std::cout << "Please enter a non-empty item name.\n";
                }
                else {
                    const int count = inv.lookup(query);
                    std::cout << "Frequency of '" << query << "': " << count << "\n";
                }
            }
            else if (choice == 2) {
                printFrequencies(inv.allFrequencies());
            }
            else if (choice == 3) {
                printHistogram(inv.histogramLines('*'));
            }
            else if (choice == 4) {
                std::cout << "Thank you for using the Corner Grocer tracker. Goodbye!\n";
            }
            else {
                std::cout << "Invalid option. Please enter a number from 1 to 4.\n";
            }
        } while (choice != 4);
    }
    catch (const std::exception& ex) {
        std::cerr << "Error: " << ex.what() << "\n";
        return 1;
    }

    return 0;
}
